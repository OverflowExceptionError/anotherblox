import os,sys
def extract_path(relative_path):
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = os.getenv('LOCALAPPDATA')
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
print('AnotherBlox Loader and Runtime Enviroment')
data = []
if len(sys.argv) < 2:
    url = 'client://AnotherBlox;localhost;53640'
else:
    url = sys.argv[1]
url = url.split('client://')[1]
print(url)
data = url.split(';')
a = data[0]
b = data[1]
c = data[2]
d = extract_path('AnotherBlox\\Client\\RobloxApp_client.exe')
os.chdir(extract_path('AnotherBlox\\Client'))
os.system(d + ' \"\" -script \" dofile(\'rbxasset://scripts\\\\CSMPFunctions.lua\'); _G.CSConnect(0,\'' + b + '\',\'' + a + '\',' + c + ',\'NoHat.rbxm\',\'NoHat.rbxm\',\'NoHat.rbxm\',208,26,26,26,26,26,\'\',\'NoShirt.rbxm\',\'NoPants.rbxm\',\'DefaultFace.rbxm\',\'DefaultHead.rbxm\',\'NBC\',\'NoExtra.rbxm\',\'\',\'\',\'\',\'66811F45178BFBFF00870F102D230C1CC444D3D5502E085B6EFFD757\',0,false);\"')
import os
def extract_path(relative_path):
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = os.getenv('LOCALAPPDATA')
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
isServer = False
isStudio = False
isClient = True
if isClient:
    a = input('USERNAME > ')
    b = input('IP ADDRESS > ')
    c = input('PORT > ')
    os.chdir(extract_path('AnotherBlox\\Client'))
    d = extract_path('AnotherBlox\\Client\\RobloxApp_client.exe')
    print(d)
    print(d + ' \"\" -script \" dofile(\'rbxasset://scripts\\\\CSMPFunctions.lua\'); _G.CSConnect(0,\'' + b + '\',\'' + a + '\',' + c + ',\'NoHat.rbxm\',\'NoHat.rbxm\',\'NoHat.rbxm\',208,26,26,26,26,26,\'\',\'NoShirt.rbxm\',\'NoPants.rbxm\',\'DefaultFace.rbxm\',\'DefaultHead.rbxm\',\'NBC\',\'NoExtra.rbxm\',\'\',\'\',\'\',\'66811F45178BFBFF00870F102D230C1CC444D3D5502E085B6EFFD757\',0,false);\"')
    os.system(d + ' \"\" -script \" dofile(\'rbxasset://scripts\\\\CSMPFunctions.lua\'); _G.CSConnect(0,\'' + b + '\',\'' + a + '\',' + c + ',\'NoHat.rbxm\',\'NoHat.rbxm\',\'NoHat.rbxm\',208,26,26,26,26,26,\'\',\'NoShirt.rbxm\',\'NoPants.rbxm\',\'DefaultFace.rbxm\',\'DefaultHead.rbxm\',\'NBC\',\'NoExtra.rbxm\',\'\',\'\',\'\',\'66811F45178BFBFF00870F102D230C1CC444D3D5502E085B6EFFD757\',0,false);\"')
if isServer:
    a = input('IP ADDRESS > ')
    b = input('PORT > ')
    c = input('NUMBER OF PEOPLE > ')
    os.system(extract_path("AnotherBlox\\Client\\RobloxApp_server.exe") + ' \"D:\\Novetus\\maps\\Maps released by year\\2007\\2007 - Climb the Tallest Ladder in Roblox.rbxl\" -script \" dofile(\'rbxasset://scripts\\\\CSMPFunctions.lua\'); _G.CSServer(' + b +',\'\',\'\',\'\',\'\',false,0,false);\"')
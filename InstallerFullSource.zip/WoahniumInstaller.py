# WOAHNium Roblox Client Installer
import os
from zipfile import ZipFile
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def extract_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = os.getenv('LOCALAPPDATA')
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
f = open("scratchpy.reg", "w")
f.write(r"""Windows Registry Editor Version 5.00

[HKEY_CURRENT_USER\Software\Classes\client]
@="URL: WOAHNium Client Protocol"
"URL Protocol"=""

[HKEY_CURRENT_USER\Software\Classes\ablox-client\Shell]

[HKEY_CURRENT_USER\Software\Classes\ablox-client\Shell\Open]

[HKEY_CURRENT_USER\Software\Classes\ablox-client\Shell\Open\Command]
@=\"""" + extract_path("AnotherBlox\Client\loader.exe") + """ %1\"

[HKEY_CURRENT_USER\Software\Classes\ablox-studio]
@="URL: WOAHNium Studio Protocol"
"URL Protocol"=""

[HKEY_CURRENT_USER\Software\Classes\ablox-studio\Shell]

[HKEY_CURRENT_USER\Software\Classes\ablox-studio\Shell\Open]

[HKEY_CURRENT_USER\Software\Classes\ablox-studio\Shell\Open\Command]
@=\"""" + extract_path("AnotherBlox\Client\RobloxApp_studio.exe") + """\"

""")
f.close()
os.system("@reg import scratchpy.reg > NUL")
os.system("del /q scratchpy.reg")
# Actually do something for once dang it!
print('ANOTHERBLOX (powered by Woahnium)')
print(extract_path("AnotherBlox\loader.exe"))
print(extract_path("AnotherBlox\Client\RobloxApp_studio.exe"))
os.mkdir(extract_path('AnotherBlox'))
with ZipFile(resource_path("client.zip"),"r") as zip_ref:
    zip_ref.extractall(extract_path('AnotherBlox/Client'))
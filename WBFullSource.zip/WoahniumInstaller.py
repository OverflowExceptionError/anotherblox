# WOAHNium Roblox Client Installer
import os
from zipfile import ZipFile
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def extract_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = os.getenv('LOCALAPPDATA')
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
f = open("scratchpy.reg", "w")
f.write(r"""Windows Registry Editor Version 5.00

[HKEY_CURRENT_USER\Software\Classes\client]
@="URL: WOAHNium Client Protocol"
"URL Protocol"=""

[HKEY_CURRENT_USER\Software\Classes\client\Shell]

[HKEY_CURRENT_USER\Software\Classes\client\Shell\Open]

[HKEY_CURRENT_USER\Software\Classes\client\Shell\Open\Command]
@=\"""" + extract_path("Woahnium\Client\loader.exe") + """ %1\"

[HKEY_CURRENT_USER\Software\Classes\studio]
@="URL: WOAHNium Studio Protocol"
"URL Protocol"=""

[HKEY_CURRENT_USER\Software\Classes\studio\Shell]

[HKEY_CURRENT_USER\Software\Classes\studio\Shell\Open]

[HKEY_CURRENT_USER\Software\Classes\studio\Shell\Open\Command]
@=\"""" + extract_path("Woahnium\Client\RobloxApp_studio.exe") + """\"

""")
f.close()
os.system("@reg import scratchpy.reg > NUL")
os.system("del /q scratchpy.reg")
# Actually do something for once dang it!
print('WOAHNIUM (powered by RBXLegacy)')
print(extract_path("Woahnium\loader.exe"))
print(extract_path("Woahnium\Client\RobloxApp_studio.exe"))
os.mkdir(extract_path('Woahnium'))
with ZipFile(resource_path("client.zip"),"r") as zip_ref:
    zip_ref.extractall(extract_path('Woahnium/Client'))